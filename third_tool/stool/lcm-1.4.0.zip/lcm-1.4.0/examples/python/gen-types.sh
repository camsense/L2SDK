#!/bin/sh

lcm-gen -p ../types/*.lcm
