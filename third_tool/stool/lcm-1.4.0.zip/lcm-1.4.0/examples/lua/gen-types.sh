#!/bin/sh

lcm-gen -l ../types/example_t.lcm
